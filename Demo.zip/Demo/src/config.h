#ifndef MD_CONFIG_H_
#define MD_CONFIG_H_
#pragma once

//������
int requestId=0;

// ǰ�õ�ַ
char mdFront[]   ="tcp://asp-sim1-front1.financial-trading-platform.com:41213";
char tradeFront[]="tcp://asp-sim1-front1.financial-trading-platform.com:41205";
char riskFront[] ="tcp://asp-sim1-front1.financial-trading-platform.com:50001";

// Ӧ�õ�Ԫ
//char	appId[] = "2030";			
//char userId[] = "0000000624";		
//char riskUser[]="demo";		
//char  passwd[] = "asdfgh";	





#endif